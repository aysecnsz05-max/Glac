package dev.glac;

import org.bukkit.GameMode;
import org.bukkit.entity.Entity;

import java.util.Iterator;

/**
 * Elytra target / elytra killaura: elytra ile vururken kafa asiri doner.
 * Veride legit ort. yaw donusu ~3 derece, hileli ~10-45. 20 vurusluk pencere ortalamasi > 15 -> ALERT (ban yok).
 */
public final class ElytraRotationCheck extends Check {
    public ElytraRotationCheck() { super("ElytraRotation"); }

    @Override
    public void onAttack(PlayerData d, Entity t) {
        if (!d.player.isGliding()) { d.elyYaw.clear(); return; }
        if (d.player.getGameMode() == GameMode.CREATIVE || d.player.getAllowFlight()) return;

        double sum = 0;
        int n = 0;
        Iterator<float[]> it = d.rot.descendingIterator(); // son 10 rotasyon degisimi
        while (n < 10 && it.hasNext()) { sum += Math.abs(it.next()[0]); n++; }
        double ymean = n == 0 ? 0 : sum / n;
        Collector.sample(d, "elyYawMean", ymean);

        d.elyYaw.addLast(ymean);
        if (d.elyYaw.size() > 20) d.elyYaw.pollFirst();
        if (d.elyYaw.size() < 20) return;

        double avg = 0;
        for (double v : d.elyYaw) avg += v;
        avg /= d.elyYaw.size();
        if (avg > 15) {
            d.elyYaw.clear();
            flag(d, String.format("elytra ile vururken kafa asiri donuyor: 20 vurus ort. yaw donusu %.1f derece (legit ~3, limit 15)", avg),
                    1.5, "elyYawMean", avg, true);
        }
    }
}
