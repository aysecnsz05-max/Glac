package dev.glac;

import org.bukkit.Location;
import org.bukkit.entity.Entity;

/** Elytra hizi ve elytra fly (havada asili). FP analizli. */
public final class ElytraCheck extends Check {
    public ElytraCheck() { super("Elytra"); }

    @Override
    public void onMove(PlayerData d) {
        if (!d.player.isGliding()) { d.set("ely.start", 0); d.set("ely.hov", 0); return; }
        long now = d.moveTime;
        long start = (long) d.get("ely.start");
        if (start == 0) { d.set("ely.start", now); d.set("ely.dist", 0); return; }
        d.set("ely.dist", d.get("ely.dist") + d.dist3());
        if (now - start < 1000) return;

        double speed = d.get("ely.dist") / ((now - start) / 1000.0);
        d.set("ely.start", now);
        d.set("ely.dist", 0);
        if (d.exemptSince(start)) return;
        Collector.sample(d, "elytraSpeed", speed);

        if (speed > 75) {
            if (d.add("ely.spd", 1) >= 2)
                flag(d, String.format("elytra hizi %.1f b/s > 75 (normal elytra bu hizi asamaz)", speed), 2, "elytraSpeed", speed, true);
        } else d.add("ely.spd", -0.5);

        if (speed < 0.5) {
            if (d.add("ely.hov", 1) >= 3)
                flag(d, String.format("elytra acik ama %.2f b/s hareket (havada asili = elytra fly)", speed), 1.5, "elytraSpeed", speed, false);
        } else d.set("ely.hov", 0);
    }
}
