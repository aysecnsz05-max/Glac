package dev.glac;

import org.bukkit.GameMode;
import org.bukkit.entity.Entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Killaura / otomatik vurus ritmi: vuruslar arasi sure insan disi duzenli.
 * 20 vurusluk pencerede medyan sapma (MAD) < 5 ms, ust uste 2 pencere -> ALERT (ban yok).
 */
public final class HitRhythmCheck extends Check {
    public HitRhythmCheck() { super("HitRhythm"); }

    @Override
    public void onAttack(PlayerData d, Entity t) {
        if (d.player.isGliding() || d.player.getGameMode() == GameMode.CREATIVE) return;
        long now = System.currentTimeMillis();
        long last = (long) d.get("rh.last");
        d.set("rh.last", now);
        if (last == 0) return;
        long iv = now - last;
        if (iv <= 0 || iv >= 1500) return;

        d.rhythm.add(iv);
        if (d.rhythm.size() < 20) return;

        double med = median(d.rhythm);
        List<Long> dev = new ArrayList<>();
        for (long v : d.rhythm) dev.add((long) Math.abs(v - med));
        double mad = median(dev);
        d.rhythm.clear();
        Collector.sample(d, "intervalMad", mad);

        if (mad < 5) {
            if (d.add("rh.buf", 1) >= 2) {
                d.set("rh.buf", 1);
                flag(d, String.format("vurus araliklari cok duzenli: medyan %.0fms, sapma %.1fms (20 vurus, 2 pencere ust uste, legit ~50ms)", med, mad),
                        1.5, "intervalMad", mad, false);
            }
        } else d.add("rh.buf", -1);
    }

    private static double median(List<Long> l) {
        List<Long> c = new ArrayList<>(l);
        Collections.sort(c);
        int n = c.size();
        return n % 2 == 1 ? c.get(n / 2) : (c.get(n / 2 - 1) + c.get(n / 2)) / 2.0;
    }
}
