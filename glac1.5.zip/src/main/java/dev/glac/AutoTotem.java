package dev.glac;

import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.Locale;

/**
 * AutoTotem: totem patlayinca offhand'e yeni totemi insan disi hizli giymek.
 * Insan: gorme + tepki >= ~120ms + ping. Hile: ~ping kadar (0-50ms ekstra).
 * Olculen sure <= ping + 100ms ise "hizli" sayilir; 3 hizli (yavaslar -1) -> flag, 2 flag -> ban.
 */
public final class AutoTotem {
    private AutoTotem() {}

    static boolean hasOff(Player p) {
        return p.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    /** EntityResurrectEvent: totem offhand'ten patladiysa sayaci baslat */
    static void onPop(PlayerData d) {
        if (!hasOff(d.player)) return;
        d.totemPopAt = System.currentTimeMillis();
        d.hadOffTotem = false;
    }

    /** her tick: offhand'e totem yeniden girdi mi */
    static void tick() {
        long now = System.currentTimeMillis();
        for (PlayerData d : GlAc.all()) {
            Player p = d.player;
            if (!p.isOnline()) continue;
            boolean has = hasOff(p);
            if (has && !d.hadOffTotem && d.totemPopAt > 0) {
                long delay = now - d.totemPopAt;
                d.totemPopAt = 0;
                if (delay <= 5000) evaluate(d, delay);
            }
            d.hadOffTotem = has;
        }
    }

    private static void evaluate(PlayerData d, long delay) {
        int ping = Math.max(0, d.player.getPing());
        long limit = ping + 100;
        if (delay <= limit) {
            if (d.add("tt.buf", 1) >= 3) {
                d.set("tt.buf", 1);
                GlAc.flag(d, "AutoTotem",
                        String.format(Locale.ROOT, "totem patlayinca %d ms'de yenisini giydi (ping %d + 100 = %d ms limit, insan tepkisi >= ~120ms + ping)",
                                delay, ping, limit), 2);
            }
        } else d.add("tt.buf", -1);
    }
}
