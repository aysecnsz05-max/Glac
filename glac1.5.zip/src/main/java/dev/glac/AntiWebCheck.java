package dev.glac;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

import java.util.Locale;

/**
 * Anti-Web (NoWeb): orumcek agi hareketi yatayda ~%75, dikeyde ~%95 yavaslatir.
 * Vanilla agda yurume ~1 blok/sn, ziplama/dusme ~0. Aglarin icindeyken hizli yatay hiz veya dikey hareket -> flag.
 */
public final class AntiWebCheck extends Check {
    public AntiWebCheck() { super("AntiWeb"); }

    @Override
    public void onMove(PlayerData d) {
        Player p = d.player;
        GameMode gm = p.getGameMode();
        if (d.lastPos == null || d.pos.getWorld() != d.lastPos.getWorld() || d.isExempt()
                || p.isGliding() || gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        World w = d.pos.getWorld();
        if (!inWeb(w, d.pos) || !inWeb(w, d.lastPos)) { d.add("web.buf", -0.2); return; }

        double dt = d.moveTime - d.lastMoveTime;
        if (dt < 30 || dt > 200) return;
        double speed = d.hdist() / dt * 1000.0;
        double dy = d.pos.getY() - d.lastPos.getY();
        double limit = 2.5 * (1 + 0.2 * d.level(PotionEffectType.SPEED));

        String reason = null;
        if (speed > limit) reason = String.format(Locale.ROOT, "agin icinde %.1f b/s yurudu (vanilla ~1, limit %.1f)", speed, limit);
        else if (dy > 0.12) reason = String.format(Locale.ROOT, "agin icinde yukari %.2f blok hareket (vanilla ~0.02)", dy);
        else if (dy < -0.12) reason = String.format(Locale.ROOT, "agin icinde hizli dustu %.2f blok (vanilla ~0.01)", dy);

        if (reason != null) {
            if (d.add("web.buf", 1) >= 4) flag(d, reason, 2);
        } else d.add("web.buf", -0.5);
    }

    private static boolean inWeb(World w, Location p) {
        double[] o = {-0.29, 0, 0.29};
        double[] oy = {0.05, 0.9, 1.7};
        for (double ox : o) for (double oz : o) for (double y : oy)
            if (w.getBlockAt((int) Math.floor(p.getX() + ox), (int) Math.floor(p.getY() + y), (int) Math.floor(p.getZ() + oz))
                    .getType() == Material.COBWEB) return true;
        return false;
    }
}
