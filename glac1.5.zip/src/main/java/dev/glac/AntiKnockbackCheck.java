package dev.glac;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.Locale;

/**
 * Anti-Knockback (Velocity hilesi): sunucu knockback verir, oyuncu o yone kayar mi diye bakar.
 * Gercek oyuncu ilk ~350ms'de vuruş yonunde en az 0.8*hiz kadar kayar (vanilla ~3.5 kat). Hileci kaymaz.
 * Duvar, ag/su, sneak, elytra, knockback direnci (netherite) ve ping/TPS hesaba katilir; 3 ihlal ust uste -> flag.
 */
public final class AntiKnockbackCheck extends Check {
    public AntiKnockbackCheck() { super("AntiKnockback"); }

    @Override
    public void onVelocity(PlayerData d, Vector v) {
        Player p = d.player;
        int id = (int) d.get("kb.id") + 1;
        d.set("kb.id", id); // bekleyen eski degerlendirmeyi iptal eder
        double vh = Math.hypot(v.getX(), v.getZ());
        GameMode gm = p.getGameMode();
        if (vh < 0.25 || gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR || p.getAllowFlight()) return;
        AttributeInstance a = p.getAttribute(Attribute.GENERIC_KNOCKBACK_RESISTANCE);
        double res = a == null ? 0 : a.getValue();
        if (res >= 0.6) return;

        Location loc = p.getLocation();
        d.set("kb.x0", loc.getX()); d.set("kb.y0", loc.getY()); d.set("kb.z0", loc.getZ());
        d.set("kb.dx", v.getX() / vh); d.set("kb.dz", v.getZ() / vh);
        d.set("kb.vh", vh * (1 - res));
        long wait = 300 + Math.min(Math.max(p.getPing(), 0), 300); // ping kadar gecikme payi
        long ticks = Math.max(1, (wait + 49) / 50);
        Bukkit.getScheduler().runTaskLater(GlAc.get(), () -> evaluate(d, id), ticks);
    }

    private void evaluate(PlayerData d, int id) {
        Player p = d.player;
        if (!p.isOnline() || (int) d.get("kb.id") != id) return;
        Location loc = p.getLocation();
        World w = loc.getWorld();
        double x0 = d.get("kb.x0"), y0 = d.get("kb.y0"), z0 = d.get("kb.z0");
        double dx = d.get("kb.dx"), dz = d.get("kb.dz"), vh = d.get("kb.vh");
        if (w == null || p.isDead() || p.isGliding() || p.isSneaking() || p.isInsideVehicle()
                || p.getPing() > 300 || Collector.tps() < 17) return;
        if (Math.hypot(loc.getX() - x0, loc.getZ() - z0) > 12) return; // teleport
        try {
            if (FlyCheck.special(w, loc) || blocked(w, x0, y0, z0, dx, dz)) return;
        } catch (Throwable t) { return; }

        double disp = (loc.getX() - x0) * dx + (loc.getZ() - z0) * dz; // vurus yonunde yer degistirme
        double need = 0.8 * vh;
        if (disp < need) {
            if (d.add("kb.buf", 1) >= 3)
                flag(d, String.format(Locale.ROOT, "knockback uygulanmadi: vurus yonunde %.2f blok kaydi, beklenen >= %.2f (hiz %.2f, vanilla ~%.1f blok)",
                        disp, need, vh, vh * 3.5), 2);
        } else d.add("kb.buf", -1);
    }

    private static boolean blocked(World w, double x, double y, double z, double dx, double dz) {
        for (double dist : new double[]{0.6, 1.0, 1.5})
            for (double h : new double[]{0.2, 1.2}) {
                Block b = w.getBlockAt((int) Math.floor(x + dx * dist), (int) Math.floor(y + h), (int) Math.floor(z + dz * dist));
                if (b.getType().isSolid()) return true;
            }
        return false;
    }
}
