package dev.glac;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** GlAc ana plugin sinifi. Baska pluginlerden: GlAc.exempt(player, ms) */
public final class GlAc extends JavaPlugin implements Listener {
    public static boolean DEBUG = false; // /glac debug ile ac/kapat
    /** N flag / pencere icinde otomatik ban (config: ban-flags). Config'te yoksa bu varsayilanlar */
    private static final Map<String, Integer> DEFAULT_BAN_FLAGS = Map.of("ElytraRotation", 5, "AntiKnockback", 3, "AntiWeb", 3, "AutoTotem", 2);
    private static GlAc instance;
    private static final Map<UUID, PlayerData> DATA = new ConcurrentHashMap<>();
    private List<Check> checks;

    public static GlAc get() { return instance; }
    public static PlayerData data(Player p) { return DATA.computeIfAbsent(p.getUniqueId(), k -> new PlayerData(p)); }
    static Collection<PlayerData> all() { return DATA.values(); }
    public static void exempt(Player p, long ms) { data(p).exempt(ms); }
    static Path folder() { return instance.getDataFolder().toPath(); }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        Reference.load();
        Categories.load();
        checks = List.of(new ReachCheck(), new SpeedCheck(), new FlyCheck(), new AutoClickerCheck(),
                new KillAuraCheck(), new AimCheck(), new ElytraCheck(), new TimerCheck(), new BadPacketCheck(),
                new ElytraRotationCheck(), new HitRhythmCheck(), new AntiKnockbackCheck(), new AntiWebCheck());
        Bukkit.getPluginManager().registerEvents(this, this);
        GlNpc npc = new GlNpc();
        Bukkit.getPluginManager().registerEvents(npc, this);
        getCommand("glnpc").setExecutor(npc);
        GlAcCommand cmd = new GlAcCommand();
        getCommand("glac").setExecutor(cmd);
        getCommand("glac").setTabCompleter(cmd);
        for (Player p : Bukkit.getOnlinePlayers()) data(p).exempt(4000);

        double decay = getConfig().getDouble("decay", 1.0);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (PlayerData d : DATA.values()) d.vl.replaceAll((k, v) -> Math.max(0, v - decay));
        }, 400L, 400L);
        Bukkit.getScheduler().runTaskTimer(this, Recorder::tickDisplay, 10L, 10L);
        Bukkit.getScheduler().runTaskTimer(this, AutoTotem::tick, 1L, 1L);
        Bukkit.getScheduler().runTaskTimer(this, Reference::save, 6000L, 6000L);
        log("GlAc enabled");
    }

    @Override
    public void onDisable() {
        for (PlayerData d : DATA.values()) { Recorder.stop(d.player); Collector.finish(d); }
        Reference.save();
        Categories.save();
    }

    // ---------- events ----------
    @EventHandler public void onJoin(PlayerJoinEvent e) { data(e.getPlayer()).exempt(4000); }
    @EventHandler public void onQuit(PlayerQuitEvent e) {
        PlayerData d = DATA.remove(e.getPlayer().getUniqueId());
        if (d != null) { Recorder.stop(e.getPlayer()); Collector.finish(d); }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onTeleport(PlayerTeleportEvent e) {
        if (e.getTo() != null) data(e.getPlayer()).reset(e.getTo(), 1500);
    }
    @EventHandler public void onRespawn(PlayerRespawnEvent e) { data(e.getPlayer()).reset(e.getRespawnLocation(), 3000); }
    @EventHandler public void onWorld(PlayerChangedWorldEvent e) { data(e.getPlayer()).exempt(2000); }
    @EventHandler public void onVelocity(PlayerVelocityEvent e) { data(e.getPlayer()).exempt(1500); }
    @EventHandler public void onFlight(PlayerToggleFlightEvent e) { data(e.getPlayer()).exempt(2000); }
    @EventHandler public void onGlide(EntityToggleGlideEvent e) {
        if (e.getEntity() instanceof Player p) data(p).exempt(1000);
    }
    @EventHandler public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) data(p).exempt(1500);
    }

    /** Knockback kontrolu icin: gercekten uygulanan hizi kontrollere ilet */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onVelocityCheck(PlayerVelocityEvent e) {
        PlayerData d = data(e.getPlayer());
        org.bukkit.util.Vector v = e.getVelocity().clone();
        for (Check c : checks) run(c, () -> c.onVelocity(d, v));
    }

    /** Totem patladi: AutoTotem zamanlayicisini baslat */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onResurrect(EntityResurrectEvent e) {
        if (e.getEntity() instanceof Player p) AutoTotem.onPop(data(p));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (e.getTo() == null) return;
        PlayerData d = data(e.getPlayer());
        d.update(e.getTo());
        try { Collector.move(d); } catch (Throwable t) { log("ERROR collector: " + t); }
        for (Check c : checks) run(c, () -> c.onMove(d));
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwing(PlayerAnimationEvent e) {
        PlayerData d = data(e.getPlayer());
        d.lastSwing = System.currentTimeMillis();
        for (Check c : checks) run(c, () -> c.onSwing(d));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        PlayerData d = data(p);
        d.lastCombat = System.currentTimeMillis();
        Entity t = e.getEntity();
        if (!Recorder.isRecording(p)) {
            try { Collector.attack(d, t); } catch (Throwable x) { log("ERROR collector: " + x); }
        }
        for (Check c : checks) run(c, () -> c.onAttack(d, t));
    }

    /** Kayit: iptal edilmis (NPC) vuruslari da yakalar */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onAttackRecord(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player rp) || !Recorder.isRecording(rp)) return;
        Recorder.onAttack(data(rp), e.getEntity());
    }

    private void run(Check c, Runnable r) {
        try { r.run(); } catch (Throwable t) { log("ERROR in " + c.name + ": " + t); }
    }

    // ---------- flag / alert / ban ----------
    public static void flag(PlayerData d, String check, String info, double add) {
        instance.doFlag(d, check, info, add, null, 0, true);
    }

    public static void flag(PlayerData d, String check, String info, double add, String feature, double value, boolean high) {
        instance.doFlag(d, check, info, add, feature, value, high);
    }

    private void doFlag(PlayerData d, String check, String info, double add, String feature, double value, boolean high) {
        Player p = d.player;
        if (Recorder.isRecording(p)) return; // kayit sirasinda flag/ban yok
        double tps = Collector.tps();
        int ping = p.getPing();

        String suppress = null;
        if (tps < 17) suppress = String.format(Locale.ROOT, "dusuk TPS %.1f", tps);
        else if (ping > getConfig().getInt("max-ping", 600)) suppress = "ping " + ping + " > max";
        else if (feature != null) suppress = FpAnalyzer.check(d, feature, value, high);

        if (suppress != null) {
            flagLog(p, check, "SUPPRESSED", 0, d.vl.getOrDefault(check, 0.0), feature, value, suppress + " | " + info);
            return;
        }

        d.flagCount++;
        double vl = d.vl.merge(check, add, Double::sum);
        String vls = String.format(Locale.ROOT, "%.1f", vl);
        long nowMs = System.currentTimeMillis();
        Deque<Long> ft = d.flagTimes.computeIfAbsent(check, k -> new ArrayDeque<>());
        ft.addLast(nowMs);
        long winMs = getConfig().getLong("ban-flag-window-min", 10) * 60_000L;
        while (!ft.isEmpty() && nowMs - ft.peekFirst() > winMs) ft.pollFirst();
        int needFlags = getConfig().getInt("ban-flags." + check, DEFAULT_BAN_FLAGS.getOrDefault(check, -1));
        String progress = needFlags > 0 ? " (" + ft.size() + "/" + needFlags + ")" : "";
        String reason = info + " | ping " + ping + " | tps " + String.format(Locale.ROOT, "%.1f", tps);
        flagLog(p, check, "FLAGGED", add, vl, feature, value, reason);
        log(p.getName() + " failed " + check + " VL " + vls + " | " + reason);

        if (d.flagCount >= 3 && Categories.get(p.getUniqueId()) == Categories.Category.UNKNOWN)
            Categories.set(p.getUniqueId(), p.getName(), Categories.Category.SUSPICIOUS);

        Component msg = Component.text("GlAc » ", NamedTextColor.RED)
                .append(Component.text(p.getName(), NamedTextColor.WHITE))
                .append(Component.text(" failed " + check + " ", NamedTextColor.GRAY))
                .append(Component.text("VL " + vls + progress, NamedTextColor.RED))
                .hoverEvent(HoverEvent.showText(Component.text(reason)));
        for (Player o : Bukkit.getOnlinePlayers())
            if (o.hasPermission("glac.alerts") && data(o).alerts) o.sendMessage(msg);

        double limit = getConfig().getDouble("ban-vl." + check, -1);
        boolean byVl = limit > 0 && vl >= limit;
        boolean byFlags = needFlags > 0 && ft.size() >= needFlags;
        if (getConfig().getBoolean("auto-ban", true) && (byVl || byFlags)
                && System.currentTimeMillis() - d.joinTime > 10_000)
            ban(p, check, vl);
    }

    private void flagLog(Player p, String check, String verdict, double add, double vlTotal, String feature, double value, String reason) {
        Stats ref = feature == null ? null : Reference.get(feature);
        String m = "", sd = "", z = "";
        if (ref != null && ref.n >= 30) {
            m = fmt(ref.mean); sd = fmt(ref.std());
            if (ref.std() > 0) z = fmt((value - ref.mean) / ref.std());
        }
        String line = String.join(",", Instant.now().toString(), p.getName(), check, verdict, fmt(add), fmt(vlTotal),
                feature == null ? "" : fmt(value), m, sd, z, String.valueOf(p.getPing()), fmt(Collector.tps()),
                reason.replace(',', ';').replace('\n', ' '));
        csv("flags.csv", "time,player,check,verdict,vl_add,vl_total,value,ref_mean,ref_std,z,ping,tps,reason", line);
    }

    private static String fmt(double v) { return String.format(Locale.ROOT, "%.3f", v); }

    private void ban(Player p, String check, double vl) {
        String reason = "GlAc: Unfair advantage (" + check + ")";
        log("BAN " + p.getName() + " (" + check + " VL " + String.format(Locale.ROOT, "%.1f", vl) + ")");
        Categories.set(p.getUniqueId(), p.getName(), Categories.Category.CONFIRMED_CHEAT);
        Bukkit.getBanList(BanList.Type.NAME).addBan(p.getName(), reason, (Date) null, "GlAc");
        Component m = Component.text("GlAc » " + p.getName() + " was banned for " + check, NamedTextColor.DARK_RED);
        for (Player o : Bukkit.getOnlinePlayers()) if (o.hasPermission("glac.alerts")) o.sendMessage(m);
        p.kick(Component.text(reason, NamedTextColor.RED));
    }

    // ---------- dosya ----------
    static void csv(String file, String header, String line) {
        try {
            Path dir = folder();
            Files.createDirectories(dir);
            Path f = dir.resolve(file);
            if (!Files.exists(f)) Files.writeString(f, header + "\n", StandardOpenOption.CREATE);
            Files.writeString(f, line + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {}
    }

    static void log(String s) {
        try {
            Path dir = folder();
            Files.createDirectories(dir);
            Files.writeString(dir.resolve("glac.log"), Instant.now() + " " + s + "\n",
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {}
    }
}
