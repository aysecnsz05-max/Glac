package dev.glac;

import org.bukkit.GameMode;
import org.bukkit.entity.Entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/**
 * Elytra target / elytra killaura: elytra ile vururken kafa asiri doner.
 * Veride (tek vurus basina ort. yaw donusu): legit en fazla ~6, hileli medyan ~44.
 * Son 6 elytra vurusunun medyani > 12 -> ALERT (ban yok). 20 sn icindeki vuruslar sayilir, yere inmek sifirlamaz.
 */
public final class ElytraRotationCheck extends Check {
    private static final int WINDOW = 6;
    private static final double LIMIT = 12.0;
    private static final long MAX_AGE_MS = 20_000;

    public ElytraRotationCheck() { super("ElytraRotation"); }

    @Override
    public void onAttack(PlayerData d, Entity t) {
        if (!d.player.isGliding()) return;
        if (d.player.getGameMode() == GameMode.CREATIVE || d.player.getAllowFlight()) return;

        long now = System.currentTimeMillis();
        double sum = 0;
        int n = 0;
        Iterator<float[]> it = d.rot.descendingIterator(); // son 10 rotasyon degisimi
        while (n < 10 && it.hasNext()) { sum += Math.abs(it.next()[0]); n++; }
        double ymean = n == 0 ? 0 : sum / n;
        Collector.sample(d, "elyYawMean", ymean);

        d.elyYaw.addLast(new double[]{now, ymean});
        while (!d.elyYaw.isEmpty() && now - d.elyYaw.peekFirst()[0] > MAX_AGE_MS) d.elyYaw.pollFirst();
        while (d.elyYaw.size() > WINDOW) d.elyYaw.pollFirst();

        List<Double> vals = new ArrayList<>();
        for (double[] e : d.elyYaw) vals.add(e[1]);
        Collections.sort(vals);
        int sz = vals.size();
        double med = sz == 0 ? 0 : (sz % 2 == 1 ? vals.get(sz / 2) : (vals.get(sz / 2 - 1) + vals.get(sz / 2)) / 2.0);

        if (GlAc.DEBUG)
            GlAc.csv("elytra_debug.csv", "time,player,ymean,window_size,window_median,limit",
                    java.time.Instant.now() + "," + d.player.getName() + "," + String.format(Locale.ROOT, "%.2f,%d,%.2f,%.1f", ymean, sz, med, LIMIT));

        if (sz < WINDOW) return;
        if (med > LIMIT) {
            d.elyYaw.clear();
            flag(d, String.format(Locale.ROOT, "elytra ile vururken kafa asiri donuyor: son %d vurus medyan yaw donusu %.1f derece (legit <= 6, limit %.0f)", WINDOW, med, LIMIT),
                    1.5, "elyYawMean", med, true);
        }
    }
}
