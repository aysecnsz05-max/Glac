# GlAc (Paper 1.20.1)
plugins klasorune at. Checkler: Reach, Speed, Fly, AutoClicker, KillAura, Aim, Elytra, Timer, BadPacket.
Alertler `glac.alerts` yetkisi olana gider. Ayarlar: plugins/GlAc/config.yml. Log: plugins/GlAc/glac.log
Komut: /glac alerts | info <oyuncu> | unban <isim>
Baska pluginden muaf tutmak icin: GlAc.exempt(player, ms)
