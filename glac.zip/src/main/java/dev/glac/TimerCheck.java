package dev.glac;

/** Saniyede cok fazla hareket paketi (timer hilesi). Lag burst'lerine karsi buffer'li. */
public final class TimerCheck extends Check {
    public TimerCheck() { super("Timer"); }

    @Override
    public void onMove(PlayerData d) {
        long now = d.moveTime;
        long start = (long) d.get("tm.start");
        if (start == 0) { d.set("tm.start", now); d.set("tm.n", 0); return; }
        d.add("tm.n", 1);
        if (now - start < 1000) return;
        double n = d.get("tm.n") * 1000.0 / (now - start);
        d.set("tm.start", now);
        d.set("tm.n", 0);
        if (d.isExempt()) { d.set("tm.buf", 0); return; }
        if (n > 28) { if (d.add("tm.buf", 1) >= 4) flag(d, String.format("%.0f moves/s", n), 2); }
        else d.add("tm.buf", -1);
    }
}
