package dev.glac;

/** Welford: ortalama / standart sapma / min / max (birlestirilebilir) */
public final class Stats {
    public long n;
    public double mean, m2, min = Double.MAX_VALUE, max = -Double.MAX_VALUE;

    public void add(double x) {
        n++;
        double d = x - mean;
        mean += d / n;
        m2 += d * (x - mean);
        if (x < min) min = x;
        if (x > max) max = x;
    }

    public double std() { return n > 1 ? Math.sqrt(m2 / (n - 1)) : 0; }

    public void merge(Stats o) {
        if (o.n == 0) return;
        if (n == 0) { n = o.n; mean = o.mean; m2 = o.m2; min = o.min; max = o.max; return; }
        long t = n + o.n;
        double d = o.mean - mean;
        m2 = m2 + o.m2 + d * d * ((double) n * o.n) / t;
        mean = mean + d * o.n / t;
        n = t;
        min = Math.min(min, o.min);
        max = Math.max(max, o.max);
    }
}
