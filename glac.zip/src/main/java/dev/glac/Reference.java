package dev.glac;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Legit oyunculardan olusan istatistiksel referans (reference.yml) */
public final class Reference {
    public static final long MIN_N = 300; // bundan az orneklem varsa referans kullanilmaz
    private static final Map<String, Stats> REF = new ConcurrentHashMap<>();

    private Reference() {}

    public static Stats get(String f) { return REF.get(f); }
    public static Map<String, Stats> all() { return REF; }

    public static void merge(Profile p) {
        for (Map.Entry<String, Stats> e : p.s.entrySet())
            REF.computeIfAbsent(e.getKey(), k -> new Stats()).merge(e.getValue());
    }

    public static void load() {
        File f = GlAc.folder().resolve("reference.yml").toFile();
        if (!f.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        for (String k : y.getKeys(false)) {
            ConfigurationSection c = y.getConfigurationSection(k);
            if (c == null) continue;
            Stats s = new Stats();
            s.n = c.getLong("n"); s.mean = c.getDouble("mean"); s.m2 = c.getDouble("m2");
            s.min = c.getDouble("min"); s.max = c.getDouble("max");
            REF.put(k, s);
        }
    }

    public static void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, Stats> e : REF.entrySet()) {
            String k = e.getKey();
            Stats s = e.getValue();
            y.set(k + ".n", s.n); y.set(k + ".mean", s.mean); y.set(k + ".m2", s.m2);
            y.set(k + ".std", s.std()); y.set(k + ".min", s.min); y.set(k + ".max", s.max);
        }
        try {
            GlAc.folder().toFile().mkdirs();
            y.save(GlAc.folder().resolve("reference.yml").toFile());
        } catch (IOException ignored) {}
    }
}
