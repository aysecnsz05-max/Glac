package dev.glac;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

final class Util {
    private Util() {}

    /** bakis yonu ile hedef merkezi arasindaki aci (derece) */
    static double angle(Player p, Entity t, float yaw, float pitch) {
        Location pl = p.getLocation();
        BoundingBox bb = t.getBoundingBox();
        double vx = bb.getCenterX() - pl.getX();
        double vy = bb.getCenterY() - (pl.getY() + p.getEyeHeight());
        double vz = bb.getCenterZ() - pl.getZ();
        double len = Math.sqrt(vx * vx + vy * vy + vz * vz);
        if (len < 1e-6) return 0;
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        double lx = -Math.sin(yr) * Math.cos(pr), ly = -Math.sin(pr), lz = Math.cos(yr) * Math.cos(pr);
        double dot = (vx * lx + vy * ly + vz * lz) / len;
        return Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, dot))));
    }

    static double axis(double v, double min, double max) { return v < min ? min - v : v > max ? v - max : 0; }

    /** goz noktasindan hedef hitbox'ina en kisa mesafe */
    static double reach(Location from, Player p, Entity t) {
        BoundingBox bb = t.getBoundingBox();
        double ex = from.getX(), ey = from.getY() + p.getEyeHeight(), ez = from.getZ();
        double dx = axis(ex, bb.getMinX() - 0.1, bb.getMaxX() + 0.1);
        double dy = axis(ey, bb.getMinY(), bb.getMaxY());
        double dz = axis(ez, bb.getMinZ() - 0.1, bb.getMaxZ() + 0.1);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** hedef merkezine gore yaw hatasi (derece, +/-) */
    static double yawError(Player p, Entity t) {
        Location pl = p.getLocation();
        BoundingBox bb = t.getBoundingBox();
        double dx = bb.getCenterX() - pl.getX(), dz = bb.getCenterZ() - pl.getZ();
        double ty = Math.toDegrees(Math.atan2(-dx, dz));
        return PlayerData.wrap((float) (pl.getYaw() - ty));
    }

    /** hedef merkezine gore pitch hatasi (derece, +/-) */
    static double pitchError(Player p, Entity t) {
        Location pl = p.getLocation();
        BoundingBox bb = t.getBoundingBox();
        double dx = bb.getCenterX() - pl.getX(), dz = bb.getCenterZ() - pl.getZ();
        double dy = bb.getCenterY() - (pl.getY() + p.getEyeHeight());
        double tp = -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return pl.getPitch() - tp;
    }
}
