package dev.glac;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

/** Havada fazla yukselme, havada asili kalma, tek hamlede asiri yukselis. */
public final class FlyCheck extends Check {
    public FlyCheck() { super("Fly"); }

    @Override
    public void onMove(PlayerData d) {
        Player p = d.player;
        if (d.isExempt() || p.isGliding() || p.isRiptiding() || p.isSwimming()
                || d.level(PotionEffectType.LEVITATION) > 0 || d.level(PotionEffectType.SLOW_FALLING) > 0) {
            d.set("fly.air", 0); d.set("fly.buf", 0); return;
        }
        Location pos = d.pos, last = d.lastPos;
        if (pos.getWorld() != last.getWorld()) return;
        World w = pos.getWorld();
        double dy = pos.getY() - last.getY();

        if (special(w, pos)) { d.set("fly.air", 0); d.set("fly.buf", 0); return; }
        if (ground(w, pos)) { d.set("fly.air", 0); d.add("fly.buf", -0.5); return; }

        double air = d.add("fly.air", 1);
        if (air == 1) d.set("fly.startY", last.getY());
        int jb = d.level(PotionEffectType.JUMP);

        String reason = null;
        double rise = pos.getY() - d.get("fly.startY");
        if (rise > 1.45 + 0.6 * jb) reason = String.format("rise %.2f", rise);
        else if (dy > 0.7 + 0.15 * jb) reason = String.format("dy %.2f", dy);
        else if (air > 12 && Math.abs(dy) < 0.01 && d.hdist() > 0.15) reason = "hover " + (int) air;

        if (reason != null) {
            if (d.add("fly.buf", 1) >= 2) flag(d, reason, 1.5);
        } else d.add("fly.buf", -0.1);
    }

    static boolean ground(World w, Location p) {
        double[] o = {-0.29, 0, 0.29};
        for (double ox : o) for (double oz : o) {
            Block b = w.getBlockAt((int) Math.floor(p.getX() + ox), (int) Math.floor(p.getY() - 0.2), (int) Math.floor(p.getZ() + oz));
            if (b.getType().isSolid()) return true;
        }
        return false;
    }

    static boolean special(World w, Location p) {
        double[] o = {-0.3, 0, 0.3};
        double[] oy = {-0.1, 0.5, 1.5};
        for (double ox : o) for (double oz : o) for (double y : oy) {
            Block b = w.getBlockAt((int) Math.floor(p.getX() + ox), (int) Math.floor(p.getY() + y), (int) Math.floor(p.getZ() + oz));
            if (b.isLiquid()) return true;
            String n = b.getType().name();
            if (n.contains("LADDER") || n.contains("VINE") || n.contains("SCAFFOLDING") || n.contains("COBWEB")
                    || n.contains("BUBBLE") || n.contains("SLIME") || n.contains("HONEY") || n.contains("POWDER_SNOW")
                    || n.contains("TRAPDOOR")) return true;
        }
        return false;
    }
}
