package dev.glac;

import org.bukkit.potion.PotionEffectType;

/** 1 saniyelik pencerede ortalama yatay hiz. Anlik spike'lara degil, surekli hiza bakar. */
public final class SpeedCheck extends Check {
    public SpeedCheck() { super("Speed"); }

    @Override
    public void onMove(PlayerData d) {
        if (d.player.isGliding() || d.player.isRiptiding()) { d.set("spd.start", 0); return; }
        long now = d.moveTime;
        long start = (long) d.get("spd.start");
        if (start == 0) { d.set("spd.start", now); d.set("spd.dist", 0); return; }
        d.set("spd.dist", d.get("spd.dist") + d.hdist());
        if (now - start < 1000) return;

        double speed = d.get("spd.dist") / ((now - start) / 1000.0);
        d.set("spd.start", now);
        d.set("spd.dist", 0);
        if (d.exemptSince(start)) { d.set("spd.buf", 0); return; }

        double base = Math.max(1.0, d.player.getWalkSpeed() / 0.2); // walkSpeed 0.2 = normal
        double limit = 7.6 * base * (1 + 0.2 * d.level(PotionEffectType.SPEED)); // sprint-jump ~7.1 b/s
        if (speed > limit) {
            if (d.add("spd.buf", 1) >= 2)
                flag(d, String.format("%.2f b/s > %.2f", speed, limit), 1 + Math.min(3, (speed - limit)));
        } else d.add("spd.buf", -0.5);
    }
}
