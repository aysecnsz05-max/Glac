package dev.glac;

import org.bukkit.Location;
import org.bukkit.entity.Entity;

/** Aim assist / aimbot: sabit rotasyon delta, snap-lock, kusursuz hedefleme. */
public final class AimCheck extends Check {
    public AimCheck() { super("Aim"); }

    @Override
    public void onMove(PlayerData d) {
        long now = System.currentTimeMillis();
        if (now - d.lastCombat > 3000 || d.player.isGliding() || d.isExempt()) return;

        // 1) ayni yaw delta'si art arda tekrar (insan fare hareketi bunu yapmaz)
        if (Math.abs(d.dYaw) > 1.5 && Math.abs(d.dYaw - d.lastDYaw) < 0.0005) {
            if (d.add("aim.const", 1) >= 5) { flag(d, "constant yaw delta " + d.dYaw, 1.5); d.set("aim.const", 0); }
        } else d.set("aim.const", 0);

        // 2) snap: buyuk donus -> hemen durma, tekrar tekrar
        if (Math.abs(d.dYaw) > 35) d.set("aim.snapAt", now);
        else if (now - (long) d.get("aim.snapAt") < 100 && Math.abs(d.dYaw) < 1.0 && now - d.lastCombat < 500) {
            d.set("aim.snapAt", 0);
            if (d.add("aim.snap", 1) >= 6) { flag(d, "snap aim", 1.5); d.set("aim.snap", 3); }
        }
        d.add("aim.snap", -0.02);
    }

    @Override
    public void onAttack(PlayerData d, Entity t) {
        if (d.player.isGliding() || t.getWorld() != d.player.getWorld()) return;
        Location l = d.player.getLocation();
        if (Util.reach(l, d.player, t) < 2.0) return;
        double ang = Util.angle(d.player, t, l.getYaw(), l.getPitch());
        if (ang < 0.5) {
            if (d.add("aim.lock", 1) >= 12) { flag(d, "perfect lock x12", 2); d.set("aim.lock", 6); }
        } else d.set("aim.lock", 0);
    }
}
