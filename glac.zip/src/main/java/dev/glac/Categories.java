package dev.glac;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/** Oyuncu kategorisi: LEGIT / SUSPICIOUS / CONFIRMED_CHEAT (categories.yml) */
public final class Categories {
    public enum Category { UNKNOWN, LEGIT, SUSPICIOUS, CONFIRMED_CHEAT }

    private static YamlConfiguration y = new YamlConfiguration();

    private Categories() {}

    private static File file() { return GlAc.folder().resolve("categories.yml").toFile(); }

    public static void load() {
        File f = file();
        if (f.exists()) y = YamlConfiguration.loadConfiguration(f);
    }

    public static void save() {
        try { GlAc.folder().toFile().mkdirs(); y.save(file()); } catch (IOException ignored) {}
    }

    public static Category get(UUID id) {
        String v = y.getString(id + ".category");
        if (v == null) return Category.UNKNOWN;
        try { return Category.valueOf(v); } catch (IllegalArgumentException e) { return Category.UNKNOWN; }
    }

    public static void set(UUID id, String name, Category c) {
        y.set(id + ".name", name);
        y.set(id + ".category", c.name());
        save();
    }

    public static int count(Category c) {
        int n = 0;
        for (String k : y.getKeys(false)) {
            ConfigurationSection s = y.getConfigurationSection(k);
            if (s != null && c.name().equals(s.getString("category"))) n++;
        }
        return n;
    }
}
