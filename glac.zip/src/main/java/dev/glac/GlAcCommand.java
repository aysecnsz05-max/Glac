package dev.glac;

import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class GlAcCommand implements CommandExecutor, TabCompleter {
    private static final String USAGE = "§c/glac alerts | info <oyuncu> | unban <isim> | mark <oyuncu> <legit|suspicious|cheat> | stats | record start <etiket> | record stop";

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("glac.admin")) { s.sendMessage("§cYetkin yok."); return true; }
        if (a.length == 0) { s.sendMessage(USAGE); return true; }
        switch (a[0].toLowerCase()) {
            case "alerts" -> {
                if (s instanceof Player p) {
                    PlayerData d = GlAc.data(p);
                    d.alerts = !d.alerts;
                    p.sendMessage("§cGlAc §7alerts: " + (d.alerts ? "§aacik" : "§ckapali"));
                }
            }
            case "info" -> {
                Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : null;
                if (t == null) { s.sendMessage("§cOyuncu yok."); return true; }
                s.sendMessage("§cGlAc §7" + t.getName() + " | " + Categories.get(t.getUniqueId())
                        + " | VL: " + GlAc.data(t).vl + " | ping " + t.getPing()
                        + String.format(Locale.ROOT, " | tps %.1f", Collector.tps()));
            }
            case "unban" -> {
                if (a.length < 2) return true;
                Bukkit.getBanList(BanList.Type.NAME).pardon(a[1]);
                s.sendMessage("§cGlAc §7" + a[1] + " unbanlandi.");
            }
            case "mark" -> {
                if (a.length < 3) { s.sendMessage(USAGE); return true; }
                Categories.Category cat = switch (a[2].toLowerCase()) {
                    case "legit" -> Categories.Category.LEGIT;
                    case "suspicious", "supheli" -> Categories.Category.SUSPICIOUS;
                    case "cheat", "confirmed" -> Categories.Category.CONFIRMED_CHEAT;
                    default -> null;
                };
                if (cat == null) { s.sendMessage(USAGE); return true; }
                OfflinePlayer op = Bukkit.getOfflinePlayer(a[1]);
                Categories.set(op.getUniqueId(), a[1], cat);
                s.sendMessage("§cGlAc §7" + a[1] + " -> " + cat);
            }
            case "stats" -> {
                s.sendMessage("§cGlAc §7kategoriler: LEGIT " + Categories.count(Categories.Category.LEGIT)
                        + " | SUSPICIOUS " + Categories.count(Categories.Category.SUSPICIOUS)
                        + " | CHEAT " + Categories.count(Categories.Category.CONFIRMED_CHEAT));
                s.sendMessage("§7Legit referans (min " + Reference.MIN_N + " ornek gerekir):");
                for (Map.Entry<String, Stats> e : Reference.all().entrySet()) {
                    Stats st = e.getValue();
                    s.sendMessage(String.format(Locale.ROOT, "§7%s: n=%d ort=%.2f std=%.2f min=%.2f max=%.2f%s",
                            e.getKey(), st.n, st.mean, st.std(), st.min, st.max, st.n >= Reference.MIN_N ? " §a✔" : " §e..."));
                }
            }
            case "record" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length >= 3 && a[1].equalsIgnoreCase("start")) s.sendMessage("§cGlAc §7" + Recorder.start(p, a[2]));
                else if (a.length >= 2 && a[1].equalsIgnoreCase("stop")) s.sendMessage("§cGlAc §7" + Recorder.stop(p));
                else s.sendMessage(USAGE);
            }
            default -> s.sendMessage(USAGE);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        return a.length == 1 ? List.of("alerts", "info", "unban", "mark", "stats", "record") : null;
    }
}
