package dev.glac;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Entity;

/** Coklu hedef + bakmadan vurma. Flagler yanlis pozitif analizinden gecer. */
public final class KillAuraCheck extends Check {
    public KillAuraCheck() { super("KillAura"); }

    @Override
    public void onAttack(PlayerData d, Entity t) {
        if (d.player.getGameMode() == GameMode.CREATIVE) return;
        long now = System.currentTimeMillis();
        d.targets.put(t.getEntityId(), now);
        d.targets.values().removeIf(x -> now - x > 500);
        if (d.targets.size() >= 3) {
            if (d.add("ka.multi", 1) >= 2)
                flag(d, "500ms icinde " + d.targets.size() + " farkli hedefe vurdu (5sn'de " + d.switchTimes.size() + " hedef degisimi)",
                        2, "targetSwitch", d.switchTimes.size(), true);
        } else d.add("ka.multi", -0.2);

        if (t.getWorld() != d.player.getWorld()) return;
        double dist = Util.reach(d.player.getLocation(), d.player, t);
        if (dist > 1.2) {
            Location l = d.player.getLocation();
            double ang = Util.angle(d.player, t, l.getYaw(), l.getPitch());
            if (d.lastPos != null) ang = Math.min(ang, Util.angle(d.player, t, d.yaw, d.pitch));
            double limit = 70 + Math.min(d.player.getPing(), 300) * 0.05; // ping toleransi
            if (ang > limit) {
                if (d.add("ka.angle", 1) >= 3)
                    flag(d, String.format("hedefe bakmadan vurdu: aci %.0f > %.0f derece, mesafe %.1f", ang, limit, dist),
                            2, "aimAngle", ang, true);
            } else d.add("ka.angle", -0.3);
        }
    }
}
