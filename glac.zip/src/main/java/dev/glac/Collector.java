package dev.glac;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.Locale;
import java.util.UUID;

/** Hareket, rotasyon, combat, reach, elytra ve hedef degistirme verilerini toplar. */
public final class Collector {
    public static final String[] FEATURES = {"hspeed", "yawDelta", "pitchDelta", "atkInterval", "reach",
            "aimAngle", "targetSwitch", "elytraSpeed", "elyAimAngle", "ping", "tps"};

    private Collector() {}

    public static double tps() {
        try { return Math.min(20.0, Bukkit.getTPS()[0]); } catch (Throwable t) { return 20.0; }
    }

    /** Sadece iyi kosullarda (ping <= 300, TPS >= 18) ornek al */
    public static void sample(PlayerData d, String f, double v) {
        Player p = d.player;
        if (p.getPing() > 300 || tps() < 18) return;
        if (Recorder.isRecording(p)) {
            Profile r = Recorder.legitProfile(p);
            if (r != null) r.add(f, v); // cheat etiketli kayitlar referansi kirletmesin
            return;
        }
        d.profile.add(f, v);
    }

    public static void move(PlayerData d) {
        if (d.isExempt() || d.player.isGliding()) return;
        double dt = d.moveTime - d.lastMoveTime;
        double h = d.hdist();
        if (h > 0.02 && dt >= 30 && dt <= 150) sample(d, "hspeed", h / dt * 1000.0);
        if (System.currentTimeMillis() - d.lastCombat < 3000) {
            if (Math.abs(d.dYaw) > 0.01) sample(d, "yawDelta", Math.abs(d.dYaw));
            if (Math.abs(d.dPitch) > 0.01) sample(d, "pitchDelta", Math.abs(d.dPitch));
        }
    }

    public static void attack(PlayerData d, Entity t) {
        Player p = d.player;
        long now = System.currentTimeMillis();
        if (d.lastAttack > 0 && now - d.lastAttack < 2000) sample(d, "atkInterval", now - d.lastAttack);
        d.lastAttack = now;
        d.attacks++;
        if (t.getWorld() == p.getWorld()) {
            var l = p.getLocation();
            sample(d, "reach", Util.reach(l, p, t));
            double ang = Util.angle(p, t, l.getYaw(), l.getPitch());
            sample(d, "aimAngle", ang);
            if (p.isGliding()) sample(d, "elyAimAngle", ang);
        }
        if (d.lastTargetId != t.getEntityId()) { d.switchTimes.addLast(now); d.lastTargetId = t.getEntityId(); }
        while (!d.switchTimes.isEmpty() && now - d.switchTimes.peekFirst() > 5000) d.switchTimes.pollFirst();
        sample(d, "targetSwitch", d.switchTimes.size());
        sample(d, "ping", p.getPing());
        sample(d, "tps", tps());
    }

    /** Oyuncu cikinca: kategori belirle, legit ise referansa ekle, oturum satirini yaz. */
    public static void finish(PlayerData d) {
        Player p = d.player;
        UUID id = p.getUniqueId();
        Categories.Category c = Categories.get(id);
        double minutes = (System.currentTimeMillis() - d.joinTime) / 60000.0;
        if (c == Categories.Category.UNKNOWN) {
            if (d.flagCount >= 3) c = Categories.Category.SUSPICIOUS;
            else if (GlAc.get().getConfig().getBoolean("auto-legit", true)
                    && d.flagCount == 0 && d.profile.n("reach") >= 300 && minutes >= 10)
                c = Categories.Category.LEGIT;
            if (c != Categories.Category.UNKNOWN) Categories.set(id, p.getName(), c);
        }
        if (c == Categories.Category.LEGIT) Reference.merge(d.profile);
        writeRow(id, p.getName(), c.name(), minutes, d.flagCount, d.profile);
    }

    public static void writeRow(UUID id, String name, String cat, double minutes, int flags, Profile prof) {
        StringBuilder h = new StringBuilder("time,uuid,name,category,minutes,flags");
        StringBuilder r = new StringBuilder(java.time.Instant.now() + "," + id + "," + name + "," + cat + ","
                + String.format(Locale.ROOT, "%.1f", minutes) + "," + flags);
        for (String f : FEATURES) {
            h.append(',').append(f).append("_n,").append(f).append("_mean,").append(f).append("_std");
            Stats s = prof.s.get(f);
            if (s == null) r.append(",0,,");
            else r.append(',').append(s.n).append(',').append(String.format(Locale.ROOT, "%.3f,%.3f", s.mean, s.std()));
        }
        GlAc.csv("profiles.csv", h.toString(), r.toString());
    }
}
