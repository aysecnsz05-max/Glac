package dev.glac;

import java.util.LinkedHashMap;
import java.util.Map;

/** Bir oyuncunun/oturumun ozellik istatistikleri */
public final class Profile {
    public final Map<String, Stats> s = new LinkedHashMap<>();
    public void add(String f, double v) { s.computeIfAbsent(f, k -> new Stats()).add(v); }
    public long n(String f) { Stats x = s.get(f); return x == null ? 0 : x.n; }
}
