package dev.glac;

import org.bukkit.GameMode;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

/** Hitbox'a mesafe. Ping + hareket toleransi var, 2 ardisik ihlal gerekir. */
public final class ReachCheck extends Check {
    public ReachCheck() { super("Reach"); }

    @Override
    public void onAttack(PlayerData d, Entity t) {
        Player p = d.player;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        if (t.getWorld() != p.getWorld()) return;
        double dist = Util.reach(p.getLocation(), p, t);
        if (d.lastPos != null && d.lastPos.getWorld() == p.getWorld())
            dist = Math.min(dist, Util.reach(d.lastPos, p, t)); // lag telafisi
        double allowed = 3.0 + 0.35 + Math.min(p.getPing(), 300) * 0.002 + Math.max(0, 20 - Collector.tps()) * 0.03; // ping + TPS toleransi
        if (dist > allowed) {
            if (d.add("reach.buf", 1) >= 2)
                flag(d, String.format("reach %.2f > %.2f", dist, allowed), 1 + Math.min(3, (dist - allowed) * 2));
        } else d.add("reach.buf", -0.3);
    }
}
