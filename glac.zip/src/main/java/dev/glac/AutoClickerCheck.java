package dev.glac;

/** Asiri CPS + insan disi tutarlilik (dusuk standart sapma). */
public final class AutoClickerCheck extends Check {
    public AutoClickerCheck() { super("AutoClicker"); }

    @Override
    public void onSwing(PlayerData d) {
        long now = System.currentTimeMillis();
        if (!d.clicks.isEmpty()) {
            long iv = now - d.clicks.peekLast();
            if (iv < 400) {
                d.intervals.addLast(iv);
                if (d.intervals.size() > 60) d.intervals.pollFirst();
            }
        }
        d.clicks.addLast(now);
        while (!d.clicks.isEmpty() && now - d.clicks.peekFirst() > 1000) d.clicks.pollFirst();

        int cps = d.clicks.size();
        if (cps >= 30) flag(d, "cps " + cps, 3);
        else if (cps >= 23) { if (d.add("ac.cps", 1) >= 3) { flag(d, "cps " + cps, 1.5); d.set("ac.cps", 1); } }
        else d.add("ac.cps", -0.05);

        if (d.intervals.size() >= 50) {
            double mean = 0, var = 0;
            for (long v : d.intervals) mean += v;
            mean /= d.intervals.size();
            for (long v : d.intervals) var += (v - mean) * (v - mean);
            double std = Math.sqrt(var / d.intervals.size());
            if (mean < 160 && std < 7) {
                if (d.add("ac.std", 1) >= 2) flag(d, String.format("std %.1fms mean %.0fms", std, mean), 2);
            } else d.add("ac.std", -0.5);
            d.intervals.clear();
        }
    }
}
