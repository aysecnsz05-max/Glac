package dev.glac;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;

/** /glnpc olustur : legit veri toplama NPC'si. Sag tik = kayit ac/kapat, vurunca olcer. */
public final class GlNpc implements Listener, CommandExecutor {
    private final NamespacedKey key = new NamespacedKey(GlAc.get(), "glac_npc");

    private boolean isNpc(Entity e) { return e.getPersistentDataContainer().has(key, PersistentDataType.BYTE); }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p) || !p.hasPermission("glac.admin")) { s.sendMessage("§cYetkin yok."); return true; }
        String sub = a.length > 0 ? a[0].toLowerCase() : "";
        switch (sub) {
            case "olustur" -> {
                Location loc = p.getLocation();
                loc.setYaw(loc.getYaw() + 180);
                Entity ent = loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
                Villager v = (Villager) ent;
                v.setAI(false);
                v.setSilent(true);
                v.setPersistent(true);
                v.setRemoveWhenFarAway(false);
                v.setCollidable(false);
                v.setCanPickupItems(false);
                v.customName(Component.text("GlAc Legit NPC", NamedTextColor.GREEN));
                v.setCustomNameVisible(true);
                v.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
                p.sendMessage("§cGlAc §7NPC olusturuldu. §aSag tikla§7 = legit kayit baslat/durdur. Sonra NPC'ye vur.");
            }
            case "sil" -> {
                int n = 0;
                for (Entity en : p.getNearbyEntities(10, 10, 10)) if (isNpc(en)) { en.remove(); n++; }
                p.sendMessage("§cGlAc §7" + n + " NPC silindi.");
            }
            case "hepsi" -> {
                int n = 0;
                for (World w : org.bukkit.Bukkit.getWorlds())
                    for (Entity en : w.getEntities()) if (isNpc(en)) { en.remove(); n++; }
                p.sendMessage("§cGlAc §7" + n + " NPC silindi.");
            }
            default -> p.sendMessage("§c/glnpc olustur | sil | hepsi");
        }
        return true;
    }

    /** NPC hic olmez, hasar iptal. Kayit MONITOR'da iptal edilmis olayi da gorur. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent e) {
        if (isNpc(e.getEntity())) e.setCancelled(true);
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!isNpc(e.getRightClicked())) return;
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("glac.admin")) return;
        String msg = Recorder.isRecording(p) ? Recorder.stop(p) : Recorder.start(p, "legit");
        p.sendMessage("§cGlAc §7" + msg);
    }
}
