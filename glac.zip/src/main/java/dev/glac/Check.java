package dev.glac;

import org.bukkit.entity.Entity;

public abstract class Check {
    public final String name;
    protected Check(String name) { this.name = name; }
    public void onMove(PlayerData d) {}
    public void onAttack(PlayerData d, Entity target) {}
    public void onSwing(PlayerData d) {}

    protected void flag(PlayerData d, String info, double vl) { GlAc.flag(d, name, info, vl); }

    /** feature+value verilirse yanlis pozitif analizi (legit referans) devreye girer */
    protected void flag(PlayerData d, String info, double vl, String feature, double value, boolean high) {
        GlAc.flag(d, name, info, vl, feature, value, high);
    }
}
