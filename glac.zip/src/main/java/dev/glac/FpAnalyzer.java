package dev.glac;

/**
 * Yanlis pozitif analizi: bir flag, legit referans dagilimina uyuyorsa bastirilir.
 * Dondurulen yazi = bastirma nedeni, null = gercek flag.
 */
public final class FpAnalyzer {
    static final double HIGH_K = 4.0, LOW_K = 3.0;

    private FpAnalyzer() {}

    public static String check(PlayerData d, String feature, double value, boolean high) {
        Stats s = Reference.get(feature);
        if (s == null || s.n < Reference.MIN_N) return null; // yeterli referans yok -> bastirma yok
        double std = s.std();
        if (high) {
            double lim = s.mean + HIGH_K * std;
            if (value <= lim)
                return String.format("legit referansi icinde: %s=%.2f <= %.2f (ref %.2f+-%.2f n=%d)",
                        feature, value, lim, s.mean, std, s.n);
        } else {
            double lim = s.mean - LOW_K * std;
            if (lim > 0 && value >= lim)
                return String.format("legit referansi icinde: %s=%.2f >= %.2f (ref %.2f+-%.2f n=%d)",
                        feature, value, lim, s.mean, std, s.n);
        }
        return null;
    }
}
