package dev.glac;

import org.bukkit.Location;
import org.bukkit.entity.Entity;

/** Elytra hizi, elytra fly (havada asili) ve elytra target lock. FP analizli. */
public final class ElytraCheck extends Check {
    public ElytraCheck() { super("Elytra"); }

    @Override
    public void onMove(PlayerData d) {
        if (!d.player.isGliding()) { d.set("ely.start", 0); d.set("ely.hov", 0); return; }
        long now = d.moveTime;
        long start = (long) d.get("ely.start");
        if (start == 0) { d.set("ely.start", now); d.set("ely.dist", 0); return; }
        d.set("ely.dist", d.get("ely.dist") + d.dist3());
        if (now - start < 1000) return;

        double speed = d.get("ely.dist") / ((now - start) / 1000.0);
        d.set("ely.start", now);
        d.set("ely.dist", 0);
        if (d.exemptSince(start)) return;
        Collector.sample(d, "elytraSpeed", speed);

        if (speed > 75) {
            if (d.add("ely.spd", 1) >= 2)
                flag(d, String.format("elytra hizi %.1f b/s > 75 (normal elytra bu hizi asamaz)", speed), 2, "elytraSpeed", speed, true);
        } else d.add("ely.spd", -0.5);

        if (speed < 0.5) {
            if (d.add("ely.hov", 1) >= 3)
                flag(d, String.format("elytra acik ama %.2f b/s hareket (havada asili = elytra fly)", speed), 1.5, "elytraSpeed", speed, false);
        } else d.set("ely.hov", 0);
    }

    @Override
    public void onAttack(PlayerData d, Entity t) {
        if (!d.player.isGliding() || t.getWorld() != d.player.getWorld()) { d.set("ely.lock", 0); return; }
        double speed = d.dist3() / Math.max(0.05, (d.moveTime - d.lastMoveTime) / 1000.0);
        Location l = d.player.getLocation();
        double ang = Util.angle(d.player, t, l.getYaw(), l.getPitch());
        if (speed > 12 && ang < 1.0) {
            if (d.add("ely.lock", 1) >= 6)
                flag(d, String.format("hizli ucarken 6 vurus ust uste hedef merkezine kilitli (aci %.2f)", ang), 2, "elyAimAngle", ang, false);
        } else if (ang > 2.5) d.set("ely.lock", 0);
    }
}
