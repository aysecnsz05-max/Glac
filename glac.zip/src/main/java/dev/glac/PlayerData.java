package dev.glac;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public final class PlayerData {
    public final Player player;
    public final long joinTime = System.currentTimeMillis();
    public Location pos, lastPos;
    public long moveTime, lastMoveTime, exemptUntil, lastSwing, lastCombat;
    public float yaw, pitch, dYaw, dPitch, lastDYaw, lastDPitch;
    public boolean alerts = true;
    public final Map<String, Double> vl = new HashMap<>();
    public final Deque<Long> clicks = new ArrayDeque<>();
    public final Deque<Long> intervals = new ArrayDeque<>();
    public final Map<Integer, Long> targets = new HashMap<>();
    public final Deque<float[]> rot = new ArrayDeque<>();
    public final Profile profile = new Profile();
    public long lastAttack, attacks;
    public int lastTargetId = -1, flagCount;
    public final Deque<Long> switchTimes = new ArrayDeque<>();
    private final Map<String, Double> nums = new HashMap<>();

    public PlayerData(Player p) { this.player = p; }

    public double get(String k) { return nums.getOrDefault(k, 0.0); }
    public void set(String k, double v) { nums.put(k, v); }
    /** buffer ekler, 0'in altina inmez, yeni degeri dondurur */
    public double add(String k, double v) {
        double n = Math.max(0, get(k) + v);
        nums.put(k, n);
        return n;
    }

    public void update(Location to) {
        lastPos = pos; lastMoveTime = moveTime;
        pos = to.clone(); moveTime = System.currentTimeMillis();
        float ly = yaw;
        float lp = pitch;
        yaw = to.getYaw(); pitch = to.getPitch();
        lastDYaw = dYaw; lastDPitch = dPitch;
        dYaw = wrap(yaw - ly); dPitch = pitch - lp;
        rot.addLast(new float[]{dYaw, dPitch});
        if (rot.size() > 20) rot.pollFirst();
        if (lastPos != null && (lastPos.getWorld() != pos.getWorld() || lastPos.distance(pos) > 8)) exempt(1500);
    }

    /** teleport/respawn sonrasi konumu sifirla */
    public void reset(Location to, long exemptMs) {
        pos = to.clone(); lastPos = to.clone(); moveTime = System.currentTimeMillis();
        yaw = to.getYaw(); pitch = to.getPitch(); dYaw = 0; dPitch = 0;
        for (String k : new String[]{"spd.start", "ely.start", "tm.start", "fly.air"}) set(k, 0);
        exempt(exemptMs);
    }

    static float wrap(float a) {
        a %= 360;
        if (a > 180) a -= 360;
        if (a < -180) a += 360;
        return a;
    }

    public void exempt(long ms) { exemptUntil = Math.max(exemptUntil, System.currentTimeMillis() + ms); }

    public boolean isExempt() {
        GameMode gm = player.getGameMode();
        long now = System.currentTimeMillis();
        return lastPos == null || now < exemptUntil || now - joinTime < 4000
                || gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR
                || player.getAllowFlight() || player.isFlying()
                || player.isInsideVehicle() || player.isDead();
    }

    /** verilen zamandan beri herhangi bir an muaf miydi */
    public boolean exemptSince(long since) { return isExempt() || exemptUntil > since; }

    public double hdist() {
        if (pos == null || lastPos == null || pos.getWorld() != lastPos.getWorld()) return 0;
        double dx = pos.getX() - lastPos.getX(), dz = pos.getZ() - lastPos.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    public double dist3() {
        if (pos == null || lastPos == null || pos.getWorld() != lastPos.getWorld()) return 0;
        return pos.distance(lastPos);
    }

    /** efekt seviyesi, yoksa 0 */
    public int level(PotionEffectType t) {
        PotionEffect e = player.getPotionEffect(t);
        return e == null ? 0 : e.getAmplifier() + 1;
    }
}
