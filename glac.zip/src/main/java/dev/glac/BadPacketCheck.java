package dev.glac;

/** Imkansiz degerler: pitch > 90, NaN/sonsuz konum. */
public final class BadPacketCheck extends Check {
    public BadPacketCheck() { super("BadPacket"); }

    @Override
    public void onMove(PlayerData d) {
        float pitch = d.pos.getPitch();
        if (Float.isNaN(pitch) || Math.abs(pitch) > 90.5f) flag(d, "invalid pitch " + pitch, 5);
    }
}
