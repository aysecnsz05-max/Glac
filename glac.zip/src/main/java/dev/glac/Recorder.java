package dev.glac;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Kayit oturumlari: "legit" etiketi referansa girer, baska etiketler (cheat_x) sadece CSV'ye yazilir. */
public final class Recorder {
    private static final class Session {
        final String label; final Path file; final BufferedWriter w; final boolean legit; final long start = System.currentTimeMillis();
        final Profile prof = new Profile();
        int rows; double lAngle, lYaw, lPitch, lReach;
        Session(String label, Path file, BufferedWriter w) {
            this.label = label; this.file = file; this.w = w; this.legit = label.equalsIgnoreCase("legit");
        }
    }
    private static final Map<UUID, Session> SESSIONS = new ConcurrentHashMap<>();

    private Recorder() {}

    public static boolean isRecording(Player p) { return SESSIONS.containsKey(p.getUniqueId()); }

    /** legit oturumunun profili, legit degilse null */
    public static Profile legitProfile(Player p) {
        Session s = SESSIONS.get(p.getUniqueId());
        return s != null && s.legit ? s.prof : null;
    }

    public static String start(Player p, String label) {
        if (isRecording(p)) return "Zaten kayitta. Once durdur.";
        label = label.replaceAll("[^a-zA-Z0-9_-]", "");
        if (label.isEmpty()) label = "legit";
        try {
            Path dir = GlAc.folder().resolve("data");
            Files.createDirectories(dir);
            Path f = dir.resolve(label + "_" + System.currentTimeMillis() + ".csv");
            BufferedWriter w = Files.newBufferedWriter(f);
            StringBuilder h = new StringBuilder("label,ping,tps,dist,angle,yawErr,pitchErr,hspeed,cps,glide,interval");
            for (int i = 0; i < 10; i++) h.append(",y").append(i);
            for (int i = 0; i < 10; i++) h.append(",p").append(i);
            w.write(h.append("\n").toString());
            w.flush();
            SESSIONS.put(p.getUniqueId(), new Session(label, f, w));
            return "Kayit basladi (" + label + "). Vur! Durdurmak icin NPC'ye tekrar sag tikla.";
        } catch (IOException e) { return "Hata: " + e.getMessage(); }
    }

    public static String stop(Player p) {
        Session s = SESSIONS.remove(p.getUniqueId());
        if (s == null) return "Kayit yok.";
        try { s.w.close(); } catch (IOException ignored) {}
        Stats a = s.prof.s.get("aimAngle");
        String extra = "";
        if (s.legit && s.rows > 0) {
            Reference.merge(s.prof);
            Reference.save();
            double min = (System.currentTimeMillis() - s.start) / 60000.0;
            Collector.writeRow(p.getUniqueId(), p.getName() + "[npc]", "LEGIT", min, 0, s.prof);
            Stats ra = Reference.get("aimAngle");
            extra = " Referansa eklendi (toplam aci ornegi: " + (ra == null ? 0 : ra.n) + ").";
        }
        return "Kayit bitti: " + s.rows + " vurus"
                + (a != null ? String.format(Locale.ROOT, ", ort aci %.1f+-%.1f", a.mean, a.std()) : "")
                + "." + extra + " Dosya: plugins/GlAc/data/" + s.file.getFileName();
    }

    public static void onAttack(PlayerData d, Entity t) {
        Player p = d.player;
        Session s = SESSIONS.get(p.getUniqueId());
        if (s == null || t.getWorld() != p.getWorld()) return;
        long now = System.currentTimeMillis();
        long interval = d.lastAttack > 0 ? now - d.lastAttack : 0;
        d.lastCombat = now;
        Location l = p.getLocation();
        double dist = Util.reach(l, p, t);
        double ang = Util.angle(p, t, l.getYaw(), l.getPitch());
        double yawErr = Util.yawError(p, t), pitchErr = Util.pitchError(p, t);
        double hspeed = d.hdist() / Math.max(0.05, (d.moveTime - d.lastMoveTime) / 1000.0);
        Collector.attack(d, t);

        StringBuilder r = new StringBuilder(s.label);
        r.append(',').append(p.getPing()).append(',').append(f(Collector.tps()));
        r.append(',').append(f(dist)).append(',').append(f(ang)).append(',').append(f(yawErr)).append(',').append(f(pitchErr));
        r.append(',').append(f(hspeed)).append(',').append(d.clicks.size()).append(',').append(p.isGliding() ? 1 : 0);
        r.append(',').append(interval);
        for (int axis = 0; axis < 2; axis++) {
            Iterator<float[]> it = d.rot.descendingIterator(); // en yeni basta
            for (int i = 0; i < 10; i++) r.append(',').append(it.hasNext() ? f(it.next()[axis]) : "0");
        }
        try {
            s.w.write(r.append('\n').toString());
            s.w.flush();
        } catch (IOException ignored) {}
        s.rows++;
        s.lAngle = ang; s.lYaw = yawErr; s.lPitch = pitchErr; s.lReach = dist;
    }

    /** Ekranda (action bar) canli gosterge */
    public static void tickDisplay() {
        for (Map.Entry<UUID, Session> e : SESSIONS.entrySet()) {
            Player p = Bukkit.getPlayer(e.getKey());
            if (p == null) continue;
            Session s = e.getValue();
            Stats a = s.prof.s.get("aimAngle");
            String avg = a != null ? String.format(Locale.ROOT, " | ort %.1f+-%.1f", a.mean, a.std()) : "";
            String msg = String.format(Locale.ROOT, "%s | %d vurus | aci %.1f (y %+.1f p %+.1f) | %.2fm | %d CPS%s",
                    s.legit ? "LEGIT" : "REC " + s.label, s.rows, s.lAngle, s.lYaw, s.lPitch, s.lReach,
                    GlAc.data(p).clicks.size(), avg);
            p.sendActionBar(Component.text(msg, s.legit ? NamedTextColor.GREEN : NamedTextColor.RED));
        }
    }

    private static String f(double v) { return String.format(Locale.ROOT, "%.4f", v); }
}
