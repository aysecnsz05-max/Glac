plugins { java }
group = "dev.glac"
version = "1.3"
repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}
dependencies {
    compileOnly("io.papermc.paper:paper-api:1.20.1-R0.1-SNAPSHOT")
}
tasks.withType<JavaCompile> { options.release.set(17) }
